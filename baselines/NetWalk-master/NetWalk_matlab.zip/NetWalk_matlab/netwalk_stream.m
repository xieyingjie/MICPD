%% clear and add folder 
%  add folder to current working directory
clear; clc;
addpath framework/ optimize/

%% hyperparameters
%   ---------------------------------------------
%   parameter           symbol      default value
%   ---------------------------------------------
%   walk_len            l           3
%   sample_per_node     k           20
%   ini_graph_percent               20%
%   snapshot_edge       m           100
%   anomaly_percent                 5%

% rng(1);

%% data sets
%  * uci_message
%  * arXiv hep-th
%  * Digg
%  * DBLP
%  Here, we use uci_message for example;
dataset = 'uci_message';

%% initial graph
%  we only select part of the edges to included in the network 
%  for initial training, all the remaining edges are treated as
%  testing edges coming in a streaming way
ini_graph_percent = 0.5;

%% inject anomaly
%  all anomaly edges are randomly generated that are not
%  shown in the original network(grand-truth networ) and inject them in the
%  testing edges
anomaly_percent = 0.05;

%% simulate different snapshots in a streaming way
%  number of edges in each sanpshot for updating learning model
snapshot_edge = 500;


walk_len = 3;           % number of nodes in one walk
sample_per_node = 20;%10;%50;   % number of walk's for each node

d = 5;                  % number of hidden layer
rho = 0.2;              % rho, spasity parameter
gama = 30;              % weight of autoencoder (reconstruction error)
beta = 0.2;             % weight of sparsity regularization
lamda = 5e-4;           % weight decay parameter  

k = 10;                 % kmeans clustering

%% load data TODO: change it to load networks later
fprintf('[%s] loading dataset %s...\n', datestr(now, 'mm/dd/yy HH:MM:SS'), dataset);

% in case that the original graph is too dense
% we can subsample of edges for experiments
sample_rate = 1%0.1;% 1;

%% different datasets' loading
switch dataset
    case 'uci_message'
        % % <matlab:function [data, n, m] = load_uci_message(sample_rate)>
        [data, n, m] = load_uci_message(sample_rate);
    case 'digg'
        [data, n, m] = load_digg(sample_rate);
    case 'hep_th'
        [data, n, m] = load_hep_th(sample_rate);
    case 'dblp'
        [data, n, m] = load_dblp(sample_rate);
end

%% generate anomaly
% split the whole graph into training network which includes parts of the
% whole graph edges(with ini_graph_percent) and testing edges that includes
% a ratio of manually injected anomaly edges, here anomaly edges mean that
% they are not shown in previous graph;
[synthetic_test, train_mat, train] = anomaly_generation(ini_graph_percent, anomaly_percent, data, n, m);

%% initial graph walk generation
tic
[walks_onehot, reservoir, degree, walks] = netwalk_generation(train_mat, n, walk_len, sample_per_node);
fprintf('[%s] initial graph walk generation time %.2f (s).\n', datestr(now, 'mm/dd/yy HH:MM:SS'), toc)

%% method selection, both 'fast' and 'scalable' are 2 layer neural network
%  'fast' is faster than 'scalable' but uses more memory, for large graph,
%  typically use 'scalable'. 'deep' is the method with 6 layers in the
%  neural network, 3 layers encoding and 3 layers decoding
options.method = 'fast'
%% initial embedding
% invoke initialization function for parameters in the embedding network to
% be optimized, here initialize(d,n) is using one layer for encoding and another
% layer for decoding. If you use 6 layers(3 encoding+ 3 decoding), please 
% use initialize_deep(d, n) function instead. Note that in current version,
% the total number of layers in the learning network is hard coded with 2
% layers or 6 layers only.
switch options.method
        case 'fast'
            options.theta = initialize(d, n);  % options.theta includes all parameters to optimize
        case 'scalable'
            options.theta = initialize(d, n);  % options.theta includes all parameters to optimize
        case 'deep'
            options.theta = initialize_deep(d, n);  % options.theta includes all parameters to optimize
end
options.dataset = dataset;         % name of dataset
options.ini_graph_percent = ini_graph_percent;  % percentage of deges selected in the initial network for model training
options.anomaly_percent = anomaly_percent; % percentage of edges in testing edge pool to be injected anomalies 
options.walk_len = walk_len;        % number of nodes in one walk
options.sample_per_node = sample_per_node; % number of walk's for each node
options.d = d;                      % number of hidden layer
options.rho = rho;                  % rho, spasity parameter
options.gama = gama;                % weight of autoencoder (reconstruction error)
options.beta = beta;                % weight of sparsity regularization
options.lamda = lamda;              % weight decay parameter  
options.n = n;                      % number of nodes in the whole network
options.m = m;                      % number of total edges in the whole network
options.walks_onehot = walks_onehot;% onehot vectors in all sampled walks
options.snapshots = 0;              % snapshot id, start from 0 for initial graph
tic

%% Conduct netwalk embedding in the initial network(graph) 
% The initial network includes part of edges(e.g., 0.5 percentage of all edges) 
[embedding, opttheta] = netwalk_embedding( options ); 
% embedding \in R^ n*d
% plot(embedding(:,1),embedding(:,2),'.')
fprintf('[%s] initial graph embedding time %.2f (s).\n', datestr(now, 'mm/dd/yy HH:MM:SS'), toc)

%% edge encoding and clustering

%% static anomaly detection in the initial network
% The test edges are the top-ranked 100 edges in the testing edge pool
[scores, auc, n0, c0 ] = anomaly_detection(embedding, train, synthetic_test(1:100,:), k);
fprintf('[%s] auc score testing: %.2f.at snapshot:0\n', datestr(now, 'mm/dd/yy HH:MM:SS'), auc)

%% dynamically streaming in batch of edges in sequential snapshots

% calculate number of snapshots for upcoming new edges
snapshots = floor(length(synthetic_test)/snapshot_edge);

old_walks = walks;

% simulating batch of new edges streaming in
% each snapshot conducts one model updating, each snapshot includes
% $snapshot_edge$ of edges
for i = 1:snapshots
    start_idx = (i-1)*snapshot_edge + 1;
    end_idx = i*snapshot_edge;
    new_edges = synthetic_test(start_idx:end_idx, :);
    new_walks = [];
    for e = 1:length(new_edges)
        % first update node degrees
        % refer Section 3.4 of KDD paper
        node_in = new_edges(e,1);
        node_out = new_edges(e,2);
        degree(node_in) = degree(node_in) + 1;
        degree(node_out) = degree(node_out) + 1;
        
        % update reservoir of src node -- be careful when update new vertex
        tmp_reservoir_src = datasample(1:degree(node_in), sample_per_node);
        reservoir(node_in, tmp_reservoir_src == degree(node_in)) = node_out;
        
        % update reservoir of dst node
        tmp_reservoir_dst = datasample(1:degree(node_out), sample_per_node);
        reservoir(node_out, tmp_reservoir_dst == degree(node_out)) = node_in;
        
        % generate new walks for src node
        idx_src = find(tmp_reservoir_src == degree(node_in));
        new_walks_src = [repmat([node_in node_out], length(idx_src) * sample_per_node, 1), datasample(reservoir(node_out,:), length(idx_src) * sample_per_node)'];
        
        % generate new walks for dst node
        idx_dst = find(tmp_reservoir_dst == degree(node_out));
        new_walks_dst = [repmat([node_out node_in], length(idx_dst) * sample_per_node, 1), datasample(reservoir(node_in,:), length(idx_dst) * sample_per_node)'];
        
        % one hot encoding
        new_walks = [new_walks; new_walks_src; new_walks_dst];
    end
    
    % 0.1 percentage of old walks will be maintained and added with new
    % generated walks for new edges
    sample_old_walk = datasample(old_walks, floor(length(old_walks) * 0.1), 'Replace',false);
    new_walks = [sample_old_walk; new_walks];
    flat_walk = new_walks';
    new_walks_onehot = sparse(flat_walk(:), 1:length(new_walks) * walk_len, ones(length(new_walks) * walk_len,1), n, length(new_walks) * walk_len);
    
    % update walks_onehot that includes new walks information for re-training
    options.walks_onehot = new_walks_onehot;
    
    % warm-up initialization for model updating with new training data
    options.theta = opttheta;
    
    % record new snapshot id
    options.snapshots = i;  

    % recalculating node embeddings with new traing data(walks)
    [embedding, opttheta] = netwalk_embedding( options ); 
    
    % calculate anomaly detection auc after adding new batch of edges
    [scores, auc, n0, c0] = anomaly_detection_stream(embedding, train, new_edges, k, 0.1, n0, c0);
    fprintf('[%s] auc score testing: %.2f.at snapshot:%d\n', datestr(now, 'mm/dd/yy HH:MM:SS'), auc, i)

    % update old walks
    old_walks = new_walks;
end
