function [ scores, auc, n, c ] = anomaly_detection(embedding, train, synthetic_test, k)
%% function anomaly_detection(embedding, train, synthetic_test, k)
%  the function generate codes of edges by combining embeddings of two
%  nodes, and then using the testing codes of edges for anomaly detection
fprintf('[%s] edge encoding...\n', datestr(now, 'mm/dd/yy HH:MM:SS'))

src = embedding(train(:,1), :);
dst = embedding(train(:,2), :);
test_src = embedding(synthetic_test(:,1),:);
test_dst = embedding(synthetic_test(:,2),:);


% the edge encoding
% refer Section 3.3 Edge Encoding in the KDD paper for details
encoding_method = 'Hadamard';
switch encoding_method
    case 'Average'
        codes = (src + dst)/2;
        test_codes = (test_src + test_dst)/2;
    case 'Hadamard'
        codes = src.*dst;
        test_codes = test_src.*test_dst;
    case 'WeightedL1'
        codes = abs(src - dst);
        test_codes = abs(test_src - test_dst);
    case 'WeightedL2'
        codes = (src - dst).^2;
        test_codes = (test_src - test_dst).^2;
end

fprintf('[%s] anomaly detection...\n', datestr(now, 'mm/dd/yy HH:MM:SS'))

% conducting k-means clustering and recording centroids of different
% clusters
[indices, centroids] = kmeans(codes, k);
tbl = tabulate(indices);
n = tbl(:,2);
c = centroids;
assert(length(n) == k);

labels = synthetic_test(:,3);

% calculating distances for testing edge codes to centroids of clusters
dist_center = pdist2(test_codes, centroids);

% assinging each testing edge code to nearest centroid
min_dist = min(dist_center, [], 2);

% sorting distances of testing edges to their nearst centroids
[~, scores] = sort(min_dist);

% calculating auc score of anomly detection task
auc = roc_plot(labels, scores);
end
