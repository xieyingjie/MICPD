function [ synthetic_test, train_mat, train ] = anomaly_generation( ini_graph_percent, anomaly_percent, data, n, m )
%% generate anomaly
% split the whole graph into training network which includes parts of the
% whole graph edges(with ini_graph_percent) and testing edges that includes
% a ratio of manually injected anomaly edges, here anomaly edges mean that
% they are not shown in previous graph;
%  input: ini_graph_percent: percentage of edges in the whole graph will be
%                             sampled in the intitial graph for embedding
%                             learning
%         anomaly_percent: percentage of edges in testing edges pool to be
%                           manually injected anomaly edges(previous not
%                           shown in the whole graph)
%         data: whole graph matrix in sparse form, each row (nodeID,
%               nodeID) is one edge of the graph
%         n:  number of total nodes of the whole graph
%         m:  number of edges in the whole graph
%  output: synthetic_test: the testing edges with injected abnormal edges,
%                          each row is one edge (nodeID, nodeID, label),
%                          label==0 means the edge is normal one, label ==1
%                          means the edge is abnormal;
%          train_mat: the training network with square matrix format, the training
%                     network edges for initial model training;
%          train:  the sparse format of the training network, each row
%                     (nodeID, nodeID)
fprintf('[%s] generating anomalous dataset...\n', datestr(now, 'mm/dd/yy HH:MM:SS'))
fprintf('[%s] initial network edge percent: %.1f%%, anomaly percent: %.1f%%.\n', ...
    datestr(now, 'mm/dd/yy HH:MM:SS'), ini_graph_percent*100, anomaly_percent*100)

% ini_graph_percent = 0.5;
% anomaly_percent = 0.05;
train_num = floor(ini_graph_percent * m);

% select part of edges as in the training set
train = data(1:train_num, :);

% select the other edges as the testing set
test = data(train_num+1:end, :);

% generate fake edges that are not exist in the whole graph, treat them as
% anamalies
fake_edges = [datasample(1:n, m)' datasample(1:n, m)'];
idx_fake = find(fake_edges(:, 1) > fake_edges(:, 2));
fake_edges(idx_fake, 1:2) = fake_edges(idx_fake, [2,1]);
fake_edges = fake_edges(fake_edges(:,1) < fake_edges(:,2), :);
fake_edges = setdiff(fake_edges, data,'rows', 'stable');

anomaly_num = floor(anomaly_percent * length(test));
anomalies = fake_edges(1:anomaly_num, :);

idx_test = zeros(length(test) + anomaly_num, 1);
% randsample: sample without replacement
% it's different from datasample!
anomaly_pos = randsample(1:length(idx_test), anomaly_num);
idx_test(anomaly_pos) = 1;
synthetic_test = [zeros(length(idx_test), 2) idx_test];
synthetic_test(idx_test==1, 1:2) = anomalies;
synthetic_test(idx_test==0, 1:2) = test;

train_mat = sparse(train(:,1), train(:,2), ones(length(train), 1), n, n); %TODO: node addition
train_mat = train_mat + train_mat';
end

