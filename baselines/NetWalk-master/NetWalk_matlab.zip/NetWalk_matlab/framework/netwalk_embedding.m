function [ embedding, opttheta ] = netwalk_embedding( options )
%% function [ embedding, opttheta ] = netwalk_embedding( options )
%   using walk data in options.walk_len to conduct node embedding;
%   all hyper-parameters are in options
%   Output:  embedding--- R^(n * d) the embeddings of each node, each row
%                           is one node, each column is one hidden
%                           dimension
%            opttheta---  the optimal parameters learned in the model, one
%                         vector that concatinating all parameters used, such as W1,
%                         W2,b1,b2
n = options.n;
d = options.d;
walk_len = options.walk_len;
rho = options.rho;
gama = options.gama;
beta = options.beta;
lamda = options.lamda;
walks_onehot = options.walks_onehot;

theta = options.theta;

%  Use minFunc to minimize the function
para.Method = 'lbfgs';

% maximum number of iterations for optimization
para.maxIter = 100;
para.display = 'off';

filename = sprintf('./data/tmp/%s/ini%g_snap%d_len%d_sample%d_d%d_gama%d_lambda%g.mat', ...
    options.dataset, options.ini_graph_percent, options.snapshots, options.walk_len, options.sample_per_node, d, gama, lamda);
if exist(filename,'file')
    opttheta = importdata(filename);
else
    %% optimization of parameters
    %  for small network use clique_embedding,
    %  for large network, use clique_embedding_scalable
    %  if you want to use deep layers(6 layers), then use
    %  clique_embedding_deep
    %  Here, we use the open source package minFunc <https://www.cs.ubc.ca/~schmidtm/Software/minFunc.html> 
    %  all codes of open source are included in ../optimize
    switch options.method
        case 'fast'
            [opttheta, ~] = minFunc( @(p) clique_embedding(p, n, d, walk_len, rho, gama, beta, lamda, walks_onehot), theta, para);
        case 'scalable'
            [opttheta, ~] = minFunc( @(p) clique_embedding_scalable(p, n, d, walk_len, rho, gama, beta, lamda, walks_onehot), theta, para);
        case 'deep'
            [opttheta, ~] = minFunc( @(p) clique_embedding_deep(p, n, d, walk_len, rho, gama, beta, lamda, walks_onehot), theta, para);
    end
    save(filename, 'opttheta');
end

W1 = reshape(opttheta(1:d*n), d, n);                % W1 in R^d*n
% W2 = reshape(opttheta(d*n+1:2*d*n), n, d);        % W2 in R^n*d
b1 = opttheta(2*d*n+1:2*d*n+d);                     % b1 in R^d
% b2 = opttheta(2*d*n+d+1:end);                     % b2 in R^d

hiddeninputs = W1 * speye(n) + b1 * ones(1, n);     % d * n
embedding = sigmoid(hiddeninputs);                  % d * n
% plot(embedding(1,:),embedding(2,:),'.')
% out = sigmoid(W2 * embedding + b2 * ones(1, n));
embedding = embedding';

end

