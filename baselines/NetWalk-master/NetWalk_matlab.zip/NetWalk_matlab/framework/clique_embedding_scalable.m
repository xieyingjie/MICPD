function [loss, grad] = clique_embedding_scalable(theta, n, d, walk_len, rho, gama, beta, lamda, data)
%% CLIQUE_EMBEDDING_SCALABLE:
% loss function: clique embedding + \gamma autoencoder + \beta sparsity + \lambda weight decay
% this is an implementation of 2 layers case of neural network, one layer
% for encoding, one layer for decoding
% The difference between this and function clique_embedding is it uses
% for-loop for each walks rather than concatinating all walks together
% Input:  theta: a vector of parameters flattened
%         walk_len: walk length
%         n: visible size, number of vertices
%         d: hidden size, feature space size
%         rho: sparsity parameter
%         gama: weight of autoencoder (reconstruction error)
%         beta: weight of sparsity regularization
%         lamda: weight of weight decay term
%         data: training data
% Output: loss---loss function value
%         grad---gradients of different parameter
                                         
W1 = reshape(theta(1:d*n), d, n);           % W1 in R^d*n
W2 = reshape(theta(d*n+1:2*d*n), n, d);     % W2 in R^n*d
b1 = theta(2*d*n+1:2*d*n+d);                % b1 in R^d
b2 = theta(2*d*n+d+1:end);                  % b2 in R^d

W2grad = zeros(n, d);
b2grad = zeros(n, 1);
W1grad = zeros(d, n);
b1grad = zeros(d, 1);

l_omega = size(data, 2);                    % dim is l * |\omega|, |\omega| = k * n, each walk has l vertices
omega = l_omega/walk_len;

squares = zeros(n, walk_len); 

phi = 1 - speye(walk_len);
D = sum(phi, 2);
L = spdiags(D,0,speye(size(phi,1)))-phi;

clique_J = 0;
W1_clique = 0; 
b1_clique = 0;

kl_sum = 0;
for i = 1:omega
    walk_data = data(:, ((i-1)*walk_len + 1):i*walk_len);
    z2 = W1 * walk_data + repmat(b1, [1, walk_len]);  % dim is d * (l * |\omega|)
    a2 = sigmoid(z2);                           % hidden layer output
    z3 = W2 * a2 + repmat(b2, [1, walk_len]);
    a3 = sigmoid(z3);                           % final output
    
    rhohats = mean(a2, 2);
    kl_sum = kl_sum + sum(rho * log(rho ./ rhohats) + (1-rho) * log((1-rho) ./ (1-rhohats)));
    
    squares = squares + (a3 - walk_data).^2;
    
    f_i = a2;
    clique_J = clique_J + trace(f_i * L * f_i');
    W1_clique = W1_clique + f_i*(L+L').*f_i.*(1-f_i)*walk_data';
    b1_clique = b1_clique + f_i*(L+L').*f_i.*(1-f_i)*ones(walk_len, 1);
    
    delta3 = -gama * (walk_data - a3) .* a3 .* (1-a3);
    beta_term = beta * (- rho ./ rhohats + (1-rho) ./ (1-rhohats));
    delta2 = ((W2' * delta3) + repmat(beta_term, [1, walk_len]) ) .* a2 .* (1-a2);

    W2grad = W2grad + delta3 * a2';
    b2grad = b2grad + sum(delta3, 2);
    W1grad = W1grad + delta2 * walk_data';
    b1grad = b1grad + sum(delta2, 2);
end

% rhohats = rhohats/l_omega;
% kl_sum = sum(rho * log(rho ./ rhohats) + (1-rho) * log((1-rho) ./ (1-rhohats)));
autoencoder_J = (gama/2) * (1/l_omega) * sum(squares(:));
weight_decay_J = (lamda/2) * (sum(W1(:).^2) + sum(W2(:).^2));
sparsity_J = (1/omega) * beta * kl_sum;
       
loss = (walk_len/l_omega) * clique_J + autoencoder_J + weight_decay_J + sparsity_J;

W2grad = (1/l_omega) * W2grad + lamda * W2;
b2grad = (1/l_omega) * b2grad;
W1grad = (1/l_omega) * W1grad + lamda * W1 + (walk_len/l_omega) * W1_clique;
b1grad = (1/l_omega) * b1grad + (walk_len/l_omega) * b1_clique;

grad = [W1grad(:) ; W2grad(:) ; b1grad(:) ; b2grad(:)];

end

function sigm = sigmoid(x)
    sigm = 1 ./ (1 + exp(-x));
end
